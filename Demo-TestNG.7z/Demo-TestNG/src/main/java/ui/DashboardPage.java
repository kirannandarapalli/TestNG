package ui;

public class DashboardPage {
	
//	@FindBy()

}
