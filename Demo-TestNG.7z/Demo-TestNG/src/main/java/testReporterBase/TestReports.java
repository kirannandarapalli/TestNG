package testReporterBase;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestReports {
	
	public static ExtentReports reporter;
	public static ExtentTest report;
	
	public void takeScreenshots() {
		reporter = new ExtentReports("D:\\Automation-TestNG\\Demo-TestNG\\test-output\\LogintoJira.html");
		report = reporter.startTest("Login to JIRA");
	}
	
	public void endTest() {
		reporter.endTest(report);
		reporter.flush();
	}
	
	public void log(LogStatus logstatus, String s) {
		report.log(logstatus, s);
	}

}
